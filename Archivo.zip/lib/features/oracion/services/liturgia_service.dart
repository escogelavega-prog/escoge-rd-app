import 'package:cloud_firestore/cloud_firestore.dart';

class LiturgiaService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String buildDateId(DateTime date) {
    final year = date.year.toString().padLeft(4, '0');
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }

  Future<Map<String, dynamic>?> obtenerLiturgiaDelDia([DateTime? date]) async {
    try {
      final targetDate = date ?? DateTime.now();
      final docId = buildDateId(targetDate);

      final todayDoc =
          await _firestore.collection('liturgia_diaria').doc(docId).get();

      if (todayDoc.exists && todayDoc.data() != null) {
        return todayDoc.data();
      }

      final fallbackQuery = await _firestore
          .collection('liturgia_diaria')
          .orderBy('fecha', descending: true)
          .limit(1)
          .get();

      if (fallbackQuery.docs.isNotEmpty) {
        return fallbackQuery.docs.first.data();
      }

      return null;
    } catch (_) {
      rethrow;
    }
  }

  Future<Map<String, dynamic>?> obtenerLiturgiaPorFecha(DateTime date) async {
    try {
      final docId = buildDateId(date);

      final doc =
          await _firestore.collection('liturgia_diaria').doc(docId).get();

      if (!doc.exists || doc.data() == null) {
        return null;
      }

      return doc.data();
    } catch (_) {
      rethrow;
    }
  }

  Stream<Map<String, dynamic>?> escucharLiturgiaDelDia([DateTime? date]) {
    final targetDate = date ?? DateTime.now();
    final docId = buildDateId(targetDate);

    return _firestore
        .collection('liturgia_diaria')
        .doc(docId)
        .snapshots()
        .map((doc) => doc.data());
  }

  Future<bool> existeLiturgiaParaFecha(DateTime date) async {
    try {
      final docId = buildDateId(date);

      final doc =
          await _firestore.collection('liturgia_diaria').doc(docId).get();

      return doc.exists;
    } catch (_) {
      return false;
    }
  }

  Future<List<Map<String, dynamic>>> obtenerUltimasLiturgias({
    int limite = 7,
  }) async {
    try {
      final query = await _firestore
          .collection('liturgia_diaria')
          .orderBy('fecha', descending: true)
          .limit(limite)
          .get();

      return query.docs.map((e) => e.data()).toList();
    } catch (_) {
      return [];
    }
  }
}

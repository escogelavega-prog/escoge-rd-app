import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:escoge/features/retiros/domain/retiro_item.dart';

class RetirosService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  RetiroItem _mapDocToRetiro(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};

    final recomendaciones =
        (data['recomendaciones'] as List?)?.map((e) => e.toString()).toList() ??
            <String>[];

    final imagePath = (data['imagenUrl'] ?? '').toString().trim().isNotEmpty
        ? (data['imagenUrl'] ?? '').toString()
        : 'assets/images/retiro_default.png';

    return RetiroItem(
      id: doc.id,
      titulo: (data['titulo'] ?? '').toString(),
      descripcion: (data['descripcion'] ?? '').toString(),
      ciudad: (data['ciudad'] ?? '').toString(),
      lugar: (data['lugar'] ?? '').toString(),
      fecha: (data['fecha'] ?? data['fechaTexto'] ?? '').toString(),
      diocesis: (data['diocesis'] ?? '').toString(),
      categoria: (data['subtitulo'] ?? 'Retiro').toString(),
      recomendaciones: recomendaciones,
      imagePath: imagePath,
      tipoFormulario: (data['tipoFormulario'] ?? 'general').toString(),
      destacado: data['destacado'] == true,
      activo: data['activo'] != false,
    );
  }

  Future<List<RetiroItem>> obtenerRetirosActivos() async {
    final snapshot = await _firestore
        .collection('retiros')
        .where('activo', isEqualTo: true)
        .get();

    final items = snapshot.docs.map(_mapDocToRetiro).toList();

    items.sort((a, b) {
      if (a.destacado != b.destacado) {
        return a.destacado ? -1 : 1;
      }
      return a.titulo.toLowerCase().compareTo(b.titulo.toLowerCase());
    });

    return items;
  }

  Future<List<RetiroItem>> obtenerRetirosDestacados() async {
    final snapshot = await _firestore
        .collection('retiros')
        .where('activo', isEqualTo: true)
        .where('destacado', isEqualTo: true)
        .limit(5)
        .get();

    final items = snapshot.docs.map(_mapDocToRetiro).toList();

    items.sort(
        (a, b) => a.titulo.toLowerCase().compareTo(b.titulo.toLowerCase()));

    return items;
  }

  Future<RetiroItem?> obtenerRetiroPrincipal() async {
    final snapshot = await _firestore
        .collection('retiros')
        .where('activo', isEqualTo: true)
        .where('destacado', isEqualTo: true)
        .limit(1)
        .get();

    if (snapshot.docs.isEmpty) return null;

    return _mapDocToRetiro(snapshot.docs.first);
  }
}

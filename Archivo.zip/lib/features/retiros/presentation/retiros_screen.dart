import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class RetirosScreen extends StatelessWidget {
  const RetirosScreen({super.key});

  static const Color primaryBlue = Color(0xFF0B1E66);
  static const Color secondaryBlue = Color(0xFF1736A2);
  static const Color gold = Color(0xFFD4AF37);
  static const Color softBackground = Color(0xFFF3F6FD);
  static const Color textPrimary = Color(0xFF1B2559);
  static const Color textSecondary = Color(0xFF667085);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: softBackground,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryBlue, secondaryBlue],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Retiros',
                        style: GoogleFonts.lora(
                          fontSize: 32,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Encuentros para vivir, renovar y profundizar la fe.',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: Colors.white.withOpacity(0.85),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 22),
                      const _HeroRetirosCard(),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Transform.translate(
              offset: const Offset(0, -14),
              child: Container(
                decoration: const BoxDecoration(
                  color: softBackground,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(28),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 32),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _SectionHeader(
                        title: 'Próximos retiros',
                        subtitle:
                            'Explora las experiencias disponibles y entra a más detalles cuando estén publicadas.',
                      ),
                      const SizedBox(height: 16),
                      const _RetirosList(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroRetirosCard extends StatelessWidget {
  const _HeroRetirosCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [
            Colors.white.withOpacity(0.10),
            Colors.white.withOpacity(0.04),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(
          color: Colors.white.withOpacity(0.12),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.10),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
            decoration: BoxDecoration(
              color: RetirosScreen.gold.withOpacity(0.16),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              'Camino y encuentro',
              style: GoogleFonts.poppins(
                color: RetirosScreen.gold,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Vive una experiencia que transforme tu corazón',
            style: GoogleFonts.lora(
              color: Colors.white,
              fontSize: 25,
              height: 1.25,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Aquí podrás descubrir próximos encuentros, fines de semana espirituales y retiros organizados por Escoge.',
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.88),
              fontSize: 13.5,
              height: 1.65,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.poppins(
            color: RetirosScreen.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          subtitle,
          style: GoogleFonts.poppins(
            color: RetirosScreen.textSecondary,
            fontSize: 13,
            height: 1.5,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class _RetirosList extends StatelessWidget {
  const _RetirosList();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('retiros').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _LoadingCard();
        }

        if (snapshot.hasError) {
          return _MessageCard(
            icon: Icons.cloud_off_rounded,
            title: 'No se pudieron cargar los retiros',
            subtitle:
                'Verifica tu conexión o revisa la configuración de Firestore.',
            actionText: 'Reintentar',
            onTap: () {},
          );
        }

        final docs = snapshot.data?.docs ?? [];

        final retirosPublicados = docs.where((doc) {
          final data = doc.data();
          final estado = (data['estado'] ?? '').toString().toLowerCase();
          return estado.isEmpty || estado == 'publicado';
        }).toList();

        if (retirosPublicados.isEmpty) {
          return _MessageCard(
            icon: Icons.event_busy_rounded,
            title: 'Aún no hay retiros disponibles',
            subtitle:
                'Cuando publiques retiros en Firestore, aparecerán aquí con una vista premium y ordenada.',
          );
        }

        return Column(
          children: retirosPublicados.map((doc) {
            final data = doc.data();

            final titulo =
                (data['nombre'] ?? data['titulo'] ?? 'Retiro espiritual')
                    .toString();

            final descripcion = (data['descripcion'] ??
                    'Próximamente más detalles de esta experiencia.')
                .toString();

            final fecha = (data['fecha'] ?? '').toString();
            final lugar =
                (data['lugar'] ?? data['ubicacion'] ?? data['ciudad'] ?? '')
                    .toString();

            final tipoEvento =
                (data['tipoEvento'] ?? data['tipo'] ?? '').toString();

            return Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: _RetiroCard(
                titulo: titulo,
                descripcion: descripcion,
                fecha: fecha,
                lugar: lugar,
                tipoEvento: tipoEvento,
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class _RetiroCard extends StatelessWidget {
  final String titulo;
  final String descripcion;
  final String fecha;
  final String lugar;
  final String tipoEvento;

  const _RetiroCard({
    required this.titulo,
    required this.descripcion,
    required this.fecha,
    required this.lugar,
    required this.tipoEvento,
  });

  String _recortarTexto(String value, {int max = 160}) {
    if (value.length <= max) return value;
    return '${value.substring(0, max).trim()}...';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (tipoEvento.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: RetirosScreen.gold.withOpacity(0.14),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                tipoEvento,
                style: GoogleFonts.poppins(
                  color: const Color(0xFF8A6A00),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          if (tipoEvento.isNotEmpty) const SizedBox(height: 12),
          Text(
            titulo,
            style: GoogleFonts.lora(
              color: RetirosScreen.textPrimary,
              fontSize: 23,
              height: 1.35,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _recortarTexto(descripcion),
            style: GoogleFonts.poppins(
              color: RetirosScreen.textSecondary,
              fontSize: 13.5,
              height: 1.65,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              if (fecha.isNotEmpty)
                _MetaChip(
                  icon: Icons.calendar_month_rounded,
                  text: fecha,
                ),
              if (lugar.isNotEmpty)
                _MetaChip(
                  icon: Icons.location_on_outlined,
                  text: lugar,
                ),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            decoration: BoxDecoration(
              color: RetirosScreen.primaryBlue,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Text(
                  'Más información',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final IconData icon;
  final String text;

  const _MetaChip({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: RetirosScreen.primaryBlue.withOpacity(0.07),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 15,
            color: RetirosScreen.primaryBlue,
          ),
          const SizedBox(width: 6),
          Text(
            text,
            style: GoogleFonts.poppins(
              color: RetirosScreen.primaryBlue,
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _LoadingCard extends StatelessWidget {
  const _LoadingCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        children: [
          const CircularProgressIndicator(
            color: RetirosScreen.primaryBlue,
            strokeWidth: 2.5,
          ),
          const SizedBox(height: 16),
          Text(
            'Cargando retiros...',
            style: GoogleFonts.poppins(
              color: RetirosScreen.textSecondary,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? actionText;
  final VoidCallback? onTap;

  const _MessageCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.actionText,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            size: 38,
            color: RetirosScreen.primaryBlue,
          ),
          const SizedBox(height: 14),
          Text(
            title,
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              color: RetirosScreen.textPrimary,
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              color: RetirosScreen.textSecondary,
              fontSize: 13,
              height: 1.6,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (actionText != null && onTap != null) ...[
            const SizedBox(height: 16),
            GestureDetector(
              onTap: onTap,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: RetirosScreen.primaryBlue,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(
                  actionText!,
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
